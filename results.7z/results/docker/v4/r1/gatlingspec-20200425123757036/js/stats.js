var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "6000",
        "ok": "5391",
        "ko": "609"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "6",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "5268",
        "ok": "5268",
        "ko": "7"
    },
    "meanResponseTime": {
        "total": "2007",
        "ok": "2233",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1366",
        "ok": "1253",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2161",
        "ok": "2409",
        "ko": "2"
    },
    "percentiles2": {
        "total": "2965",
        "ok": "3072",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4074",
        "ok": "4153",
        "ko": "2"
    },
    "percentiles4": {
        "total": "5030",
        "ok": "5051",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 969,
    "percentage": 16
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 345,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4077,
    "percentage": 68
},
    "group4": {
    "name": "failed",
    "count": 609,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "166.667",
        "ok": "149.75",
        "ko": "16.917"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1341",
        "ko": "159"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "75",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "5268",
        "ok": "5268",
        "ko": "7"
    },
    "meanResponseTime": {
        "total": "2102",
        "ok": "2351",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1356",
        "ok": "1213",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2278",
        "ok": "2511",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3030",
        "ok": "3163",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4173",
        "ok": "4279",
        "ko": "2"
    },
    "percentiles4": {
        "total": "5097",
        "ok": "5108",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 190,
    "percentage": 13
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 87,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1064,
    "percentage": 71
},
    "group4": {
    "name": "failed",
    "count": 159,
    "percentage": 11
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "37.25",
        "ko": "4.417"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1349",
        "ko": "151"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "5223",
        "ok": "5223",
        "ko": "3"
    },
    "meanResponseTime": {
        "total": "2110",
        "ok": "2346",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1341",
        "ok": "1203",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2270",
        "ok": "2505",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3063",
        "ok": "3261",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4102",
        "ok": "4175",
        "ko": "2"
    },
    "percentiles4": {
        "total": "5033",
        "ok": "5050",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 185,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 92,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1072,
    "percentage": 71
},
    "group4": {
    "name": "failed",
    "count": 151,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "37.472",
        "ko": "4.194"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1349",
        "ko": "151"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "5253",
        "ok": "5253",
        "ko": "3"
    },
    "meanResponseTime": {
        "total": "1968",
        "ok": "2188",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1358",
        "ok": "1252",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2112",
        "ok": "2354",
        "ko": "2"
    },
    "percentiles2": {
        "total": "2950",
        "ok": "3048",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4026",
        "ok": "4076",
        "ko": "2"
    },
    "percentiles4": {
        "total": "4955",
        "ok": "4963",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 253,
    "percentage": 17
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 89,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1007,
    "percentage": 67
},
    "group4": {
    "name": "failed",
    "count": 151,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "37.472",
        "ko": "4.194"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1352",
        "ko": "148"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "6",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "5238",
        "ok": "5238",
        "ko": "3"
    },
    "meanResponseTime": {
        "total": "1847",
        "ok": "2049",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1391",
        "ok": "1317",
        "ko": "1"
    },
    "percentiles1": {
        "total": "1973",
        "ok": "2218",
        "ko": "2"
    },
    "percentiles2": {
        "total": "2864",
        "ok": "2946",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4014",
        "ok": "4062",
        "ko": "3"
    },
    "percentiles4": {
        "total": "4976",
        "ok": "5025",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 341,
    "percentage": 23
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 77,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 934,
    "percentage": 62
},
    "group4": {
    "name": "failed",
    "count": 148,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "37.556",
        "ko": "4.111"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
