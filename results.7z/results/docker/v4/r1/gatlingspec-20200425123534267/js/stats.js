var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "4800",
        "ok": "4800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1791",
        "ok": "1791",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "414",
        "ok": "414",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "331",
        "ok": "331",
        "ko": "-"
    },
    "percentiles1": {
        "total": "357",
        "ok": "357",
        "ko": "-"
    },
    "percentiles2": {
        "total": "600",
        "ok": "600",
        "ko": "-"
    },
    "percentiles3": {
        "total": "905",
        "ok": "905",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1638",
        "ok": "1638",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4338,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 319,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 143,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1791",
        "ok": "1791",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "469",
        "ok": "469",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "percentiles1": {
        "total": "418",
        "ok": "417",
        "ko": "-"
    },
    "percentiles2": {
        "total": "648",
        "ok": "648",
        "ko": "-"
    },
    "percentiles3": {
        "total": "967",
        "ok": "967",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1664",
        "ok": "1664",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1049,
    "percentage": 87
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 106,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 45,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1743",
        "ok": "1743",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "399",
        "ok": "399",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "329",
        "ok": "329",
        "ko": "-"
    },
    "percentiles1": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "percentiles2": {
        "total": "584",
        "ok": "584",
        "ko": "-"
    },
    "percentiles3": {
        "total": "885",
        "ok": "885",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1622",
        "ok": "1622",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1102,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 63,
    "percentage": 5
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 35,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1745",
        "ok": "1745",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "percentiles1": {
        "total": "336",
        "ok": "336",
        "ko": "-"
    },
    "percentiles2": {
        "total": "585",
        "ok": "585",
        "ko": "-"
    },
    "percentiles3": {
        "total": "882",
        "ok": "882",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1627",
        "ok": "1627",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1091,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 80,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 29,
    "percentage": 2
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1749",
        "ok": "1749",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "393",
        "ok": "393",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "percentiles1": {
        "total": "340",
        "ok": "340",
        "ko": "-"
    },
    "percentiles2": {
        "total": "580",
        "ok": "580",
        "ko": "-"
    },
    "percentiles3": {
        "total": "881",
        "ok": "881",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1621",
        "ok": "1621",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1096,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 70,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 34,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
