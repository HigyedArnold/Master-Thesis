var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "750",
        "ok": "334",
        "ko": "416"
    },
    "minResponseTime": {
        "total": "84",
        "ok": "84",
        "ko": "10015"
    },
    "maxResponseTime": {
        "total": "10167",
        "ok": "9993",
        "ko": "10167"
    },
    "meanResponseTime": {
        "total": "7827",
        "ok": "5094",
        "ko": "10021"
    },
    "standardDeviation": {
        "total": "3105",
        "ok": "2860",
        "ko": "13"
    },
    "percentiles1": {
        "total": "10016",
        "ok": "5140",
        "ko": "10019"
    },
    "percentiles2": {
        "total": "10019",
        "ok": "7567",
        "ko": "10020"
    },
    "percentiles3": {
        "total": "10026",
        "ok": "9503",
        "ko": "10026"
    },
    "percentiles4": {
        "total": "10030",
        "ok": "9898",
        "ko": "10085"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 23,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 297,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 416,
    "percentage": 55
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.75",
        "ok": "8.35",
        "ko": "10.4"
    }
},
contents: {
"req_planr---solve-4-d1cbc": {
        type: "REQUEST",
        name: "Planr: /solve 4",
path: "Planr: /solve 4",
pathFormatted: "req_planr---solve-4-d1cbc",
stats: {
    "name": "Planr: /solve 4",
    "numberOfRequests": {
        "total": "750",
        "ok": "334",
        "ko": "416"
    },
    "minResponseTime": {
        "total": "84",
        "ok": "84",
        "ko": "10015"
    },
    "maxResponseTime": {
        "total": "10167",
        "ok": "9993",
        "ko": "10167"
    },
    "meanResponseTime": {
        "total": "7827",
        "ok": "5094",
        "ko": "10021"
    },
    "standardDeviation": {
        "total": "3105",
        "ok": "2860",
        "ko": "13"
    },
    "percentiles1": {
        "total": "10016",
        "ok": "5140",
        "ko": "10019"
    },
    "percentiles2": {
        "total": "10019",
        "ok": "7567",
        "ko": "10020"
    },
    "percentiles3": {
        "total": "10026",
        "ok": "9503",
        "ko": "10026"
    },
    "percentiles4": {
        "total": "10030",
        "ok": "9898",
        "ko": "10085"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 23,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 14,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 297,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 416,
    "percentage": 55
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.75",
        "ok": "8.35",
        "ko": "10.4"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
