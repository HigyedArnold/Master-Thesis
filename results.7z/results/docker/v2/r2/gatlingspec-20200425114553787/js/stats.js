var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "2700",
        "ok": "1210",
        "ko": "1490"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "81",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10065",
        "ok": "10022",
        "ko": "10065"
    },
    "meanResponseTime": {
        "total": "5401",
        "ok": "5394",
        "ko": "5407"
    },
    "standardDeviation": {
        "total": "4194",
        "ok": "2926",
        "ko": "4993"
    },
    "percentiles1": {
        "total": "5919",
        "ok": "5336",
        "ko": "10015"
    },
    "percentiles2": {
        "total": "10016",
        "ok": "7901",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10021",
        "ok": "9927",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "10002",
        "ko": "10024"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 78,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 29,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1103,
    "percentage": 41
},
    "group4": {
    "name": "failed",
    "count": 1490,
    "percentage": 55
},
    "meanNumberOfRequestsPerSecond": {
        "total": "64.286",
        "ok": "28.81",
        "ko": "35.476"
    }
},
contents: {
"req_planr---solve-2-ee426": {
        type: "REQUEST",
        name: "Planr: /solve 2_1",
path: "Planr: /solve 2_1",
pathFormatted: "req_planr---solve-2-ee426",
stats: {
    "name": "Planr: /solve 2_1",
    "numberOfRequests": {
        "total": "1350",
        "ok": "599",
        "ko": "751"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "81",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10065",
        "ok": "10022",
        "ko": "10065"
    },
    "meanResponseTime": {
        "total": "5393",
        "ok": "5245",
        "ko": "5511"
    },
    "standardDeviation": {
        "total": "4199",
        "ok": "2927",
        "ko": "4983"
    },
    "percentiles1": {
        "total": "5901",
        "ok": "5199",
        "ko": "10016"
    },
    "percentiles2": {
        "total": "10017",
        "ok": "7765",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10021",
        "ok": "9868",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "9995",
        "ko": "10025"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 44,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 18,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 537,
    "percentage": 40
},
    "group4": {
    "name": "failed",
    "count": 751,
    "percentage": 56
},
    "meanNumberOfRequestsPerSecond": {
        "total": "32.143",
        "ok": "14.262",
        "ko": "17.881"
    }
}
    },"req_planr---solve-2-86217": {
        type: "REQUEST",
        name: "Planr: /solve 2_2",
path: "Planr: /solve 2_2",
pathFormatted: "req_planr---solve-2-86217",
stats: {
    "name": "Planr: /solve 2_2",
    "numberOfRequests": {
        "total": "1350",
        "ok": "611",
        "ko": "739"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "150",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10029",
        "ok": "10016",
        "ko": "10029"
    },
    "meanResponseTime": {
        "total": "5410",
        "ok": "5541",
        "ko": "5302"
    },
    "standardDeviation": {
        "total": "4190",
        "ok": "2918",
        "ko": "5000"
    },
    "percentiles1": {
        "total": "5933",
        "ok": "5509",
        "ko": "10014"
    },
    "percentiles2": {
        "total": "10016",
        "ok": "8055",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10022",
        "ok": "9952",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10023",
        "ok": "10008",
        "ko": "10024"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 34,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 566,
    "percentage": 42
},
    "group4": {
    "name": "failed",
    "count": 739,
    "percentage": 55
},
    "meanNumberOfRequestsPerSecond": {
        "total": "32.143",
        "ok": "14.548",
        "ko": "17.595"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
