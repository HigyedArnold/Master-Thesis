var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "2100",
        "ok": "1823",
        "ko": "277"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "10013"
    },
    "maxResponseTime": {
        "total": "10063",
        "ok": "10017",
        "ko": "10063"
    },
    "meanResponseTime": {
        "total": "5734",
        "ok": "5083",
        "ko": "10020"
    },
    "standardDeviation": {
        "total": "3099",
        "ok": "2801",
        "ko": "5"
    },
    "percentiles1": {
        "total": "5741",
        "ok": "4971",
        "ko": "10020"
    },
    "percentiles2": {
        "total": "8551",
        "ok": "7519",
        "ko": "10022"
    },
    "percentiles3": {
        "total": "10021",
        "ok": "9613",
        "ko": "10024"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "9933",
        "ko": "10033"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 111,
    "percentage": 5
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 89,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1623,
    "percentage": 77
},
    "group4": {
    "name": "failed",
    "count": 277,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "48.837",
        "ok": "42.395",
        "ko": "6.442"
    }
},
contents: {
"req_planr---solve-2-ee426": {
        type: "REQUEST",
        name: "Planr: /solve 2_1",
path: "Planr: /solve 2_1",
pathFormatted: "req_planr---solve-2-ee426",
stats: {
    "name": "Planr: /solve 2_1",
    "numberOfRequests": {
        "total": "1050",
        "ok": "913",
        "ko": "137"
    },
    "minResponseTime": {
        "total": "82",
        "ok": "82",
        "ko": "10016"
    },
    "maxResponseTime": {
        "total": "10032",
        "ok": "10017",
        "ko": "10032"
    },
    "meanResponseTime": {
        "total": "5654",
        "ok": "4999",
        "ko": "10021"
    },
    "standardDeviation": {
        "total": "3158",
        "ok": "2859",
        "ko": "2"
    },
    "percentiles1": {
        "total": "5742",
        "ok": "4890",
        "ko": "10021"
    },
    "percentiles2": {
        "total": "8539",
        "ok": "7507",
        "ko": "10022"
    },
    "percentiles3": {
        "total": "10022",
        "ok": "9586",
        "ko": "10024"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "9940",
        "ko": "10029"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 65,
    "percentage": 6
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 47,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 801,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "count": 137,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "24.419",
        "ok": "21.233",
        "ko": "3.186"
    }
}
    },"req_planr---solve-2-86217": {
        type: "REQUEST",
        name: "Planr: /solve 2_2",
path: "Planr: /solve 2_2",
pathFormatted: "req_planr---solve-2-86217",
stats: {
    "name": "Planr: /solve 2_2",
    "numberOfRequests": {
        "total": "1050",
        "ok": "910",
        "ko": "140"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "10013"
    },
    "maxResponseTime": {
        "total": "10063",
        "ok": "10010",
        "ko": "10063"
    },
    "meanResponseTime": {
        "total": "5815",
        "ok": "5168",
        "ko": "10019"
    },
    "standardDeviation": {
        "total": "3037",
        "ok": "2739",
        "ko": "6"
    },
    "percentiles1": {
        "total": "5742",
        "ok": "5041",
        "ko": "10018"
    },
    "percentiles2": {
        "total": "8552",
        "ok": "7529",
        "ko": "10022"
    },
    "percentiles3": {
        "total": "10020",
        "ok": "9617",
        "ko": "10024"
    },
    "percentiles4": {
        "total": "10023",
        "ok": "9910",
        "ko": "10051"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 46,
    "percentage": 4
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 42,
    "percentage": 4
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 822,
    "percentage": 78
},
    "group4": {
    "name": "failed",
    "count": 140,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "24.419",
        "ok": "21.163",
        "ko": "3.256"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
