var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "3000",
        "ok": "1257",
        "ko": "1743"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "54",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10062",
        "ok": "10018",
        "ko": "10062"
    },
    "meanResponseTime": {
        "total": "5055",
        "ok": "6044",
        "ko": "4341"
    },
    "standardDeviation": {
        "total": "4372",
        "ok": "3127",
        "ko": "4964"
    },
    "percentiles1": {
        "total": "5120",
        "ok": "6362",
        "ko": "2"
    },
    "percentiles2": {
        "total": "10013",
        "ok": "9384",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10022",
        "ok": "9893",
        "ko": "10023"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "9988",
        "ko": "10024"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 57,
    "percentage": 2
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 41,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1159,
    "percentage": 39
},
    "group4": {
    "name": "failed",
    "count": 1743,
    "percentage": 58
},
    "meanNumberOfRequestsPerSecond": {
        "total": "71.429",
        "ok": "29.929",
        "ko": "41.5"
    }
},
contents: {
"req_planr---solve-2-ee426": {
        type: "REQUEST",
        name: "Planr: /solve 2_1",
path: "Planr: /solve 2_1",
pathFormatted: "req_planr---solve-2-ee426",
stats: {
    "name": "Planr: /solve 2_1",
    "numberOfRequests": {
        "total": "1500",
        "ok": "629",
        "ko": "871"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "86",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10062",
        "ok": "10011",
        "ko": "10062"
    },
    "meanResponseTime": {
        "total": "4988",
        "ok": "5952",
        "ko": "4292"
    },
    "standardDeviation": {
        "total": "4375",
        "ok": "3166",
        "ko": "4958"
    },
    "percentiles1": {
        "total": "4930",
        "ok": "6336",
        "ko": "2"
    },
    "percentiles2": {
        "total": "10006",
        "ok": "9291",
        "ko": "10021"
    },
    "percentiles3": {
        "total": "10023",
        "ok": "9900",
        "ko": "10024"
    },
    "percentiles4": {
        "total": "10024",
        "ok": "9995",
        "ko": "10024"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 34,
    "percentage": 2
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 22,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 573,
    "percentage": 38
},
    "group4": {
    "name": "failed",
    "count": 871,
    "percentage": 58
},
    "meanNumberOfRequestsPerSecond": {
        "total": "35.714",
        "ok": "14.976",
        "ko": "20.738"
    }
}
    },"req_planr---solve-2-86217": {
        type: "REQUEST",
        name: "Planr: /solve 2_2",
path: "Planr: /solve 2_2",
pathFormatted: "req_planr---solve-2-86217",
stats: {
    "name": "Planr: /solve 2_2",
    "numberOfRequests": {
        "total": "1500",
        "ok": "628",
        "ko": "872"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "54",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10049",
        "ok": "10018",
        "ko": "10049"
    },
    "meanResponseTime": {
        "total": "5121",
        "ok": "6136",
        "ko": "4390"
    },
    "standardDeviation": {
        "total": "4369",
        "ok": "3084",
        "ko": "4970"
    },
    "percentiles1": {
        "total": "5405",
        "ok": "6499",
        "ko": "2"
    },
    "percentiles2": {
        "total": "10013",
        "ok": "9410",
        "ko": "10018"
    },
    "percentiles3": {
        "total": "10021",
        "ok": "9889",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10023",
        "ok": "9974",
        "ko": "10023"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 23,
    "percentage": 2
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 19,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 586,
    "percentage": 39
},
    "group4": {
    "name": "failed",
    "count": 872,
    "percentage": 58
},
    "meanNumberOfRequestsPerSecond": {
        "total": "35.714",
        "ok": "14.952",
        "ko": "20.762"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
