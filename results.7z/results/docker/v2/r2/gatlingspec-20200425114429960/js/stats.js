var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "2400",
        "ok": "1481",
        "ko": "919"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "74",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10056",
        "ok": "10002",
        "ko": "10056"
    },
    "meanResponseTime": {
        "total": "5635",
        "ok": "5485",
        "ko": "5877"
    },
    "standardDeviation": {
        "total": "3885",
        "ok": "3050",
        "ko": "4933"
    },
    "percentiles1": {
        "total": "6054",
        "ok": "5579",
        "ko": "10016"
    },
    "percentiles2": {
        "total": "9843",
        "ok": "8383",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10020",
        "ok": "9768",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10022",
        "ok": "9942",
        "ko": "10023"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 94,
    "percentage": 4
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 48,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1339,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "count": 919,
    "percentage": 38
},
    "meanNumberOfRequestsPerSecond": {
        "total": "58.537",
        "ok": "36.122",
        "ko": "22.415"
    }
},
contents: {
"req_planr---solve-2-ee426": {
        type: "REQUEST",
        name: "Planr: /solve 2_1",
path: "Planr: /solve 2_1",
pathFormatted: "req_planr---solve-2-ee426",
stats: {
    "name": "Planr: /solve 2_1",
    "numberOfRequests": {
        "total": "1200",
        "ok": "755",
        "ko": "445"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "85",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10042",
        "ok": "9995",
        "ko": "10042"
    },
    "meanResponseTime": {
        "total": "5549",
        "ok": "5396",
        "ko": "5809"
    },
    "standardDeviation": {
        "total": "3858",
        "ok": "3031",
        "ko": "4944"
    },
    "percentiles1": {
        "total": "5976",
        "ok": "5499",
        "ko": "10016"
    },
    "percentiles2": {
        "total": "9705",
        "ok": "8193",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10020",
        "ok": "9741",
        "ko": "10021"
    },
    "percentiles4": {
        "total": "10022",
        "ok": "9952",
        "ko": "10022"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 55,
    "percentage": 5
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 23,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 677,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "count": 445,
    "percentage": 37
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.268",
        "ok": "18.415",
        "ko": "10.854"
    }
}
    },"req_planr---solve-2-86217": {
        type: "REQUEST",
        name: "Planr: /solve 2_2",
path: "Planr: /solve 2_2",
pathFormatted: "req_planr---solve-2-86217",
stats: {
    "name": "Planr: /solve 2_2",
    "numberOfRequests": {
        "total": "1200",
        "ok": "726",
        "ko": "474"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "74",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "10056",
        "ok": "10002",
        "ko": "10056"
    },
    "meanResponseTime": {
        "total": "5720",
        "ok": "5577",
        "ko": "5940"
    },
    "standardDeviation": {
        "total": "3910",
        "ok": "3067",
        "ko": "4921"
    },
    "percentiles1": {
        "total": "6201",
        "ok": "5673",
        "ko": "10015"
    },
    "percentiles2": {
        "total": "9902",
        "ok": "8566",
        "ko": "10019"
    },
    "percentiles3": {
        "total": "10021",
        "ok": "9826",
        "ko": "10022"
    },
    "percentiles4": {
        "total": "10023",
        "ok": "9930",
        "ko": "10023"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 39,
    "percentage": 3
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 25,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 662,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "count": 474,
    "percentage": 40
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.268",
        "ok": "17.707",
        "ko": "11.561"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
