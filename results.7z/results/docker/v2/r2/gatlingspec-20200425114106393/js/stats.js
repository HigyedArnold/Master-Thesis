var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1431",
        "ok": "1431",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "637",
        "ok": "637",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "384",
        "ok": "384",
        "ko": "-"
    },
    "percentiles1": {
        "total": "606",
        "ok": "606",
        "ko": "-"
    },
    "percentiles2": {
        "total": "950",
        "ok": "950",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1303",
        "ok": "1303",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1377",
        "ok": "1377",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 947,
    "percentage": 63
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 413,
    "percentage": 28
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 140,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "46.875",
        "ok": "46.875",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-2-ee426": {
        type: "REQUEST",
        name: "Planr: /solve 2_1",
path: "Planr: /solve 2_1",
pathFormatted: "req_planr---solve-2-ee426",
stats: {
    "name": "Planr: /solve 2_1",
    "numberOfRequests": {
        "total": "750",
        "ok": "750",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1431",
        "ok": "1431",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "670",
        "ok": "670",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "percentiles1": {
        "total": "651",
        "ok": "651",
        "ko": "-"
    },
    "percentiles2": {
        "total": "982",
        "ok": "982",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1318",
        "ok": "1318",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1392",
        "ok": "1392",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 458,
    "percentage": 61
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 215,
    "percentage": 29
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 77,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.438",
        "ok": "23.438",
        "ko": "-"
    }
}
    },"req_planr---solve-2-86217": {
        type: "REQUEST",
        name: "Planr: /solve 2_2",
path: "Planr: /solve 2_2",
pathFormatted: "req_planr---solve-2-86217",
stats: {
    "name": "Planr: /solve 2_2",
    "numberOfRequests": {
        "total": "750",
        "ok": "750",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1382",
        "ok": "1382",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "604",
        "ok": "604",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "387",
        "ok": "387",
        "ko": "-"
    },
    "percentiles1": {
        "total": "562",
        "ok": "562",
        "ko": "-"
    },
    "percentiles2": {
        "total": "924",
        "ok": "924",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1285",
        "ok": "1285",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1364",
        "ok": "1364",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 489,
    "percentage": 65
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 198,
    "percentage": 26
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 63,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.438",
        "ok": "23.438",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
