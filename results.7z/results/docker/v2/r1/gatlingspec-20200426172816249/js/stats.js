var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "5400",
        "ok": "5400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4119",
        "ok": "4119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1503",
        "ok": "1503",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1046",
        "ok": "1046",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1338",
        "ok": "1338",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2092",
        "ok": "2092",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3688",
        "ok": "3688",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4029",
        "ok": "4029",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1527,
    "percentage": 28
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 907,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2966,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "154.286",
        "ok": "154.286",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "78",
        "ok": "78",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4119",
        "ok": "4119",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1607",
        "ok": "1607",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1032",
        "ok": "1032",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1448",
        "ok": "1448",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2164",
        "ok": "2164",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3767",
        "ok": "3767",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4052",
        "ok": "4052",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 322,
    "percentage": 24
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 239,
    "percentage": 18
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 789,
    "percentage": 58
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "38.571",
        "ok": "38.571",
        "ko": "-"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4084",
        "ok": "4084",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1548",
        "ok": "1548",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1030",
        "ok": "1030",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1387",
        "ok": "1387",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2109",
        "ok": "2109",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3753",
        "ok": "3753",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4031",
        "ok": "4031",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 356,
    "percentage": 26
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 230,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 764,
    "percentage": 57
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "38.571",
        "ok": "38.571",
        "ko": "-"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4084",
        "ok": "4084",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1483",
        "ok": "1483",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1057",
        "ok": "1057",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1332",
        "ok": "1332",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2068",
        "ok": "2068",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3647",
        "ok": "3647",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3992",
        "ok": "3992",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 401,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 208,
    "percentage": 15
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 741,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "38.571",
        "ok": "38.571",
        "ko": "-"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4094",
        "ok": "4094",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1375",
        "ok": "1375",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1051",
        "ok": "1051",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1197",
        "ok": "1197",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2003",
        "ok": "2003",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3617",
        "ok": "3617",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4028",
        "ok": "4028",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 448,
    "percentage": 33
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 230,
    "percentage": 17
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 672,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "38.571",
        "ok": "38.571",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
