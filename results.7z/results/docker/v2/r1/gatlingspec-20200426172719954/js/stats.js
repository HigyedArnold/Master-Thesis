var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "4800",
        "ok": "4800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1323",
        "ok": "1323",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "398",
        "ok": "398",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles1": {
        "total": "370",
        "ok": "370",
        "ko": "-"
    },
    "percentiles2": {
        "total": "561",
        "ok": "561",
        "ko": "-"
    },
    "percentiles3": {
        "total": "937",
        "ok": "937",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1112",
        "ok": "1112",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4351,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 416,
    "percentage": 9
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 33,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1323",
        "ok": "1323",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "441",
        "ok": "441",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "264",
        "ok": "264",
        "ko": "-"
    },
    "percentiles1": {
        "total": "416",
        "ok": "416",
        "ko": "-"
    },
    "percentiles2": {
        "total": "594",
        "ok": "594",
        "ko": "-"
    },
    "percentiles3": {
        "total": "970",
        "ok": "970",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1148",
        "ok": "1148",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1072,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 118,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1262",
        "ok": "1262",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "274",
        "ok": "274",
        "ko": "-"
    },
    "percentiles1": {
        "total": "347",
        "ok": "347",
        "ko": "-"
    },
    "percentiles2": {
        "total": "552",
        "ok": "552",
        "ko": "-"
    },
    "percentiles3": {
        "total": "925",
        "ok": "925",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1112",
        "ok": "1112",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1090,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 101,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1213",
        "ok": "1213",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "389",
        "ok": "389",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "percentiles1": {
        "total": "378",
        "ok": "378",
        "ko": "-"
    },
    "percentiles2": {
        "total": "537",
        "ok": "537",
        "ko": "-"
    },
    "percentiles3": {
        "total": "907",
        "ok": "907",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1032",
        "ok": "1032",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1099,
    "percentage": 92
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 97,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1286",
        "ok": "1286",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "380",
        "ok": "380",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "279",
        "ok": "279",
        "ko": "-"
    },
    "percentiles1": {
        "total": "343",
        "ok": "343",
        "ko": "-"
    },
    "percentiles2": {
        "total": "551",
        "ok": "551",
        "ko": "-"
    },
    "percentiles3": {
        "total": "939",
        "ok": "939",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1134",
        "ok": "1134",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1090,
    "percentage": 91
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 100,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
