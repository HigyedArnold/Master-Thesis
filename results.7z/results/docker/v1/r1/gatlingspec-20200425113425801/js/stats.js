var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "4800",
        "ok": "4800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2280",
        "ok": "2280",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "646",
        "ok": "646",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "583",
        "ok": "583",
        "ko": "-"
    },
    "percentiles1": {
        "total": "489",
        "ok": "489",
        "ko": "-"
    },
    "percentiles2": {
        "total": "835",
        "ok": "835",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1968",
        "ok": "1968",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2152",
        "ok": "2152",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3545,
    "percentage": 74
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 525,
    "percentage": 11
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 730,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "145.455",
        "ok": "145.455",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2280",
        "ok": "2280",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "576",
        "ok": "576",
        "ko": "-"
    },
    "percentiles1": {
        "total": "540",
        "ok": "540",
        "ko": "-"
    },
    "percentiles2": {
        "total": "889",
        "ok": "889",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2006",
        "ok": "2006",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2172",
        "ok": "2172",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 858,
    "percentage": 72
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 144,
    "percentage": 12
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 198,
    "percentage": 17
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.364",
        "ok": "36.364",
        "ko": "-"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2243",
        "ok": "2243",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "644",
        "ok": "644",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "595",
        "ok": "595",
        "ko": "-"
    },
    "percentiles1": {
        "total": "467",
        "ok": "467",
        "ko": "-"
    },
    "percentiles2": {
        "total": "837",
        "ok": "837",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1983",
        "ok": "1983",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2146",
        "ok": "2146",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 886,
    "percentage": 74
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 127,
    "percentage": 11
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 187,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.364",
        "ok": "36.364",
        "ko": "-"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2259",
        "ok": "2259",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "623",
        "ok": "623",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "590",
        "ok": "590",
        "ko": "-"
    },
    "percentiles1": {
        "total": "473",
        "ok": "473",
        "ko": "-"
    },
    "percentiles2": {
        "total": "817",
        "ok": "817",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1956",
        "ok": "1956",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2128",
        "ok": "2128",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 894,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 123,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 183,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.364",
        "ok": "36.364",
        "ko": "-"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1200",
        "ok": "1200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2249",
        "ok": "2249",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "608",
        "ok": "608",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "564",
        "ok": "564",
        "ko": "-"
    },
    "percentiles1": {
        "total": "468",
        "ok": "468",
        "ko": "-"
    },
    "percentiles2": {
        "total": "779",
        "ok": "779",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1901",
        "ok": "1901",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2137",
        "ok": "2137",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 907,
    "percentage": 76
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 131,
    "percentage": 11
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 162,
    "percentage": 14
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.364",
        "ok": "36.364",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
