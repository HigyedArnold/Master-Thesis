var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "6000",
        "ok": "5235",
        "ko": "765"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "4998",
        "ok": "4998",
        "ko": "14"
    },
    "meanResponseTime": {
        "total": "2026",
        "ok": "2322",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1458",
        "ok": "1322",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2042",
        "ok": "2335",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3288",
        "ok": "3392",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4278",
        "ok": "4342",
        "ko": "3"
    },
    "percentiles4": {
        "total": "4709",
        "ok": "4722",
        "ko": "4"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 910,
    "percentage": 15
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 478,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3847,
    "percentage": 64
},
    "group4": {
    "name": "failed",
    "count": 765,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "166.667",
        "ok": "145.417",
        "ko": "21.25"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1307",
        "ko": "193"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "82",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "4998",
        "ok": "4998",
        "ko": "14"
    },
    "meanResponseTime": {
        "total": "2144",
        "ok": "2460",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1444",
        "ok": "1271",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2176",
        "ok": "2480",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3359",
        "ok": "3474",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4344",
        "ok": "4400",
        "ko": "3"
    },
    "percentiles4": {
        "total": "4745",
        "ok": "4764",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 175,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 125,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1007,
    "percentage": 67
},
    "group4": {
    "name": "failed",
    "count": 193,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "36.306",
        "ko": "5.361"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1306",
        "ko": "194"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "4966",
        "ok": "4966",
        "ko": "5"
    },
    "meanResponseTime": {
        "total": "2112",
        "ok": "2425",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1450",
        "ok": "1287",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2145",
        "ok": "2433",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3345",
        "ok": "3449",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4313",
        "ok": "4375",
        "ko": "3"
    },
    "percentiles4": {
        "total": "4669",
        "ok": "4683",
        "ko": "4"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 192,
    "percentage": 13
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 116,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 998,
    "percentage": 67
},
    "group4": {
    "name": "failed",
    "count": 194,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "36.278",
        "ko": "5.389"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1309",
        "ko": "191"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "4938",
        "ok": "4938",
        "ko": "4"
    },
    "meanResponseTime": {
        "total": "1979",
        "ok": "2267",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1442",
        "ok": "1316",
        "ko": "1"
    },
    "percentiles1": {
        "total": "2013",
        "ok": "2269",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3230",
        "ok": "3341",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4237",
        "ok": "4267",
        "ko": "2"
    },
    "percentiles4": {
        "total": "4704",
        "ok": "4712",
        "ko": "3"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 239,
    "percentage": 16
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 114,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 956,
    "percentage": 64
},
    "group4": {
    "name": "failed",
    "count": 191,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "36.361",
        "ko": "5.306"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1500",
        "ok": "1313",
        "ko": "187"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "7",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "4945",
        "ok": "4945",
        "ko": "4"
    },
    "meanResponseTime": {
        "total": "1871",
        "ok": "2137",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "1477",
        "ok": "1387",
        "ko": "1"
    },
    "percentiles1": {
        "total": "1902",
        "ok": "2114",
        "ko": "2"
    },
    "percentiles2": {
        "total": "3197",
        "ok": "3289",
        "ko": "2"
    },
    "percentiles3": {
        "total": "4193",
        "ok": "4297",
        "ko": "3"
    },
    "percentiles4": {
        "total": "4714",
        "ok": "4723",
        "ko": "4"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 304,
    "percentage": 20
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 123,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 886,
    "percentage": 59
},
    "group4": {
    "name": "failed",
    "count": 187,
    "percentage": 12
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.667",
        "ok": "36.472",
        "ko": "5.194"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
