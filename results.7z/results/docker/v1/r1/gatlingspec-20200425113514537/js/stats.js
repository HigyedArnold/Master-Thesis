var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "5400",
        "ok": "5400",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4516",
        "ok": "4516",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1744",
        "ok": "1744",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1271",
        "ok": "1271",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1754",
        "ok": "1754",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2518",
        "ok": "2518",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4185",
        "ok": "4184",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4329",
        "ok": "4329",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1863,
    "percentage": 35
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 356,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3181,
    "percentage": 59
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    }
},
contents: {
"req_planr---solve-1-f36d9": {
        type: "REQUEST",
        name: "Planr: /solve 1_1",
path: "Planr: /solve 1_1",
pathFormatted: "req_planr---solve-1-f36d9",
stats: {
    "name": "Planr: /solve 1_1",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "78",
        "ok": "78",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4516",
        "ok": "4516",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1867",
        "ok": "1867",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1254",
        "ok": "1254",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1885",
        "ok": "1885",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2643",
        "ok": "2643",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4223",
        "ok": "4223",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4368",
        "ok": "4368",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 411,
    "percentage": 30
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 94,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 845,
    "percentage": 63
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-9169a": {
        type: "REQUEST",
        name: "Planr: /solve 1_2",
path: "Planr: /solve 1_2",
pathFormatted: "req_planr---solve-1-9169a",
stats: {
    "name": "Planr: /solve 1_2",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4471",
        "ok": "4471",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1854",
        "ok": "1854",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1292",
        "ok": "1292",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1885",
        "ok": "1885",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2637",
        "ok": "2637",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4208",
        "ok": "4208",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4322",
        "ok": "4322",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 437,
    "percentage": 32
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 79,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 834,
    "percentage": 62
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-5b0ef": {
        type: "REQUEST",
        name: "Planr: /solve 1_3",
path: "Planr: /solve 1_3",
pathFormatted: "req_planr---solve-1-5b0ef",
stats: {
    "name": "Planr: /solve 1_3",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4502",
        "ok": "4502",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1722",
        "ok": "1722",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1248",
        "ok": "1248",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1748",
        "ok": "1749",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2448",
        "ok": "2447",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4137",
        "ok": "4137",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4302",
        "ok": "4302",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 461,
    "percentage": 34
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 90,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 799,
    "percentage": 59
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    },"req_planr---solve-1-e4867": {
        type: "REQUEST",
        name: "Planr: /solve 1_4",
path: "Planr: /solve 1_4",
pathFormatted: "req_planr---solve-1-e4867",
stats: {
    "name": "Planr: /solve 1_4",
    "numberOfRequests": {
        "total": "1350",
        "ok": "1350",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4447",
        "ok": "4447",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1533",
        "ok": "1533",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1260",
        "ok": "1260",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1305",
        "ok": "1305",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2312",
        "ok": "2312",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4102",
        "ok": "4102",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4300",
        "ok": "4300",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 554,
    "percentage": 41
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 93,
    "percentage": 7
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 703,
    "percentage": 52
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "37.5",
        "ok": "37.5",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
